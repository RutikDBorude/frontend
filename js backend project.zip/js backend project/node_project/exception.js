let n=5
console.log(n/0)