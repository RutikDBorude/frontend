const operations = require("./mymodule.js")

console.log(typeof operations)
console.log(operations)

console.log(operations.add(5,6))
console.log(operations.prod(5,6))
console.log(operations.sub(10,5))