/*function asyncawait(){
    console.log("first line")

    setTimeout(() => {
        console.log("line in a timeout")
        
    }, 3000);
    console.log("last line")
}
asyncawait()
*/

console.log("hello from the beginning")
async function asyncawait(){
    console.log("first line")

let data = new Promise((resolve,reject)=>{
    setTimeout(() => {
        resolve("line in a timeout")
        
    }, 3000);
})
    let result = await data
    console.log(result)
    console.log('last line')
}
asyncawait()
console.log("hello from the last")