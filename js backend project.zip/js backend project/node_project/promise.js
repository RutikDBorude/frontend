
/*
const rutikpromise = new Promise((resolve,reject) =>{

    let mind = true
    if(mind){
        resolve("yes mind is positive")
    }else{
      reject("ohh mind is negative")
    }

});

rutikpromise.then((msg)=>{
    console.log("rutik's mind :",msg)

}).catch((msg)=>{
    console.log("rutik's mind :",msg)
}).finally((msg)=>{
    console.log("I have control on my mind")
}) 
*/

/*const f1promise = new Promise((resolve,reject)=>{

    setTimeout(()=>{
      
        if(Math.random() <= 0.5){
            resolve("heads")

        }else{
            reject("tails")
        }
    },1000)
})

const f2promise = new Promise((resolve,reject)=>{

    setTimeout(()=>{
      
        if(Math.random() <= 0.5){
            resolve("heads")

        }else{
            reject("tails")
        }
    },2000)
})
const f3promise = new Promise((resolve,reject)=>{

    setTimeout(()=>{
      
        if(Math.random() <= 0.5){
            resolve("heads")

        }else{
            reject("tails")
        }
    },3000)
})




Promise.all([f1promise,f2promise,f3promise]).then((msg)=>{
    console.log(msg)
    console.log(" we have the bating")
}).catch((msg)=>{
    console.log(msg)
    console.log("we had the bowling")
})*/
const Gf1promise = new Promise((resolve,reject)=>{

    setTimeout(()=>{
      
        if(Math.random() <= 0.5){
            resolve("we are going to dinner")

        }else{
            reject("we canat go for dinner")
        }
    },1000)
})

const Gf2promise = new Promise((resolve,reject)=>{

    setTimeout(()=>{
      
        if(Math.random() <= 0.5){
            resolve("Hey i am ready to  go with you")

        }else{
            reject("Phone is not reachable")
        }
    },2000)
})
const Gf3promise = new Promise((resolve,reject)=>{

    setTimeout(()=>{
      
        if(Math.random() <= 0.5){
            resolve("thanks for asking i would like to come with you")

        }else{
            reject("Sorry i am going with my bf")
        }
    },3000)
})




Promise.any([Gf1promise,Gf2promise,Gf3promise]).then((msg)=>{
    console.log(msg)
    console.log(" yeh a got a dinner partner")
}).catch((msg)=>{
    console.log(msg)
    console.log("Ohh my luck , I didnt get any partner to go out")
})
