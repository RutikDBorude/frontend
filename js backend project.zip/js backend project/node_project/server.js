const http = require('http')

const server = http.createServer((req,res)=>{
    if(req.url == '/hello'){
        res.end('hello world !')
    }else{
        res.end("you are on the wrong page")
    }
})

server.listen(8000, ()=>{
    console.log("server is started")
})
