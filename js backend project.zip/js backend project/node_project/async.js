async  function getmessage(){
    return('hello students')
}

getmessage().then(result => console.log(result))