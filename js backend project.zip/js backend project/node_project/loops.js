/*for (i=1 ; i<=5 ; i++){
    for(j=0;j<=5;j++){
        process.stdout.write("* ")
       
    }
    console.log()
  
}*/

/*for(row=1;row<=5;row++){
    for(col=1;col<=row;col++){
        process.stdout.write("* ")

    }
    console.log()
}*/
for(row=5;row>=1;row--){
    for(col=1;col<=row;col++){
        process.stdout.write("* ")
    }
    console.log()
}