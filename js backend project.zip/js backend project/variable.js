var name

console.log(name)
var age = 8
console.log(age)
console.log("HELLO WORLD")