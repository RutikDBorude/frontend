
/*const mongoose =require('mongoose'); 
const studentModel = require("./models/student.model1");
/*write the code to connect with mongodb*/

mongoose.connect("mongodb://localhost/be_demobd")

const db = mongoose.connection //start the connection with mongodb




db.on("error",()=>{
    console.log("error while connecting to DB")
});

db.once("open",()=>{
    console.log("connected to mongodb")
    // logic to insert the data in the db
    init()
    dbQueries()
    
});

 async function init(){
    // logic to insert the data in the db
    const student = {
        name : "rutik", 
        age : 20,
        email : "rutikborude@gamil.com"

    }
const std_obj = await studentModel.create(student)
console.log(std_obj)
}

async function dbQueries(){
    //read from the student data
    //read from the objectId
    try{
        const student = await studentModel.findById("65d85234e6fcf1338e8741f91061")
        console.log(student)

    }catch(err){
        console.log(err)
    }

    // read the data from the database by name
try{
    const students =   await studentModel.find({name:"rutik"})
    console.log(students)

}catch{console.log(err)
}
//deal with the multiple conditions

const stds = await studentModel.where("age").gt("10").where("name").equals("rutik").limit(2)
console.log(stds)

//delete one document 
const student = await studentModel.deleteOne({name:"rutik"})
console.log(student)



} 