/*define the schema of the students to be stored in the DB*/

const mongoose = require("mongoose")

const studentSchema = new mongoose.Schema({
    name :{
        type : String,
        required : true

    } ,
    age :{
        type:  Number,
        min:19
    },
    email :{
        type : String,
        required :true,
        lowercase:true,
        minLength:15
    },
    subjects : [String]
   

},{versionKey:false , timestamps:true})
// go ahead and create corresponding collection in DB
module.exports = mongoose.model("student",studentSchema)
