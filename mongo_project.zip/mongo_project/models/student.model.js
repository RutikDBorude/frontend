/*define the schema of the students to be stored in the DB*/

const mongoose = require("mongoose")

const studentSchema = new mongoose.Schema({
    name : String,
    age : Number

})
// go ahead and create corresponding collection in DB
module.exports = mongoose.model("student",studentSchema)
